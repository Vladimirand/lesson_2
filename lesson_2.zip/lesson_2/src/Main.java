//**
//*Java_lesson_2_z1, z2, z3, z4, z5
//*
//*@author Vladimir Nehvedovich
//*@version dated Nov 14, 2018

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {             /*zadanie 1*/
        int[] N01 = {1, 1, 0, 0, 1, 0, 1, 1, 0, 0};
        for (int i = 0; i < 10; i++) {
            System.out.print("do: " + N01[i] + " ");
            if (N01[i] < 1) {
                N01[i] = 1;
            } else {
                N01[i] = 0;
            }
            System.out.println("posle: " + N01[i] + " ");
        }
        int[] arr = new int[8];           /* zadanie 2  */
        for (int i = 0; i < 8; i++) {
            arr[i] = 3 * i;
            System.out.println("arr[" + i + "] = " + arr[i]);
        }

        int[] N03 = {1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1};    /*zadanie 3 */
        for (int i = 0; i < 12; i++) {
            System.out.print("do: " + N03[i] + " ");
            if (N03[i] < 6) {
                N03[i] = N03[i] * 2;
            }
            System.out.println("posle: " + N03[i] + " ");
        }

        int[][] N04 = new int[4][4];            /*zadanie 4 */
        for (int i = 0; i < 4; i++) {
            System.out.println();
            for (int j = 0; j < 4; j++) {
                N04[i][j] = (i + 1) * (j + 1);
                if (i == j) {
                    N04[i][j] = 1;
                }
                if ((i == 0 & j == 3) | (i == 3 & j == 0) | (i == 1 & j == 2) | (i == 2 & j == 1)) {
                    N04[i][j] = 1;
                }
                System.out.print(N04[i][j] + " ");
            }
        }
        System.out.println();

        int[] N05 = {2, 7, 3, 2, 11, 4, 9, 1, 4, 3, 9, 2};     /*zadanie 5 */
        System.out.println();
        System.out.println("max = " + Arrays.stream(N05).max().getAsInt());
        System.out.println("min = " + Arrays.stream(N05).min().getAsInt());
    }
}





